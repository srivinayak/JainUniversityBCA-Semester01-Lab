
/*
Author: Mr. Vinay Srinivasan
Org: IIRDM
*/

#include <stdio.h>
#include <stdlib.h>

/*
C Program to Swap variable values for two variables
(a). Using a Temporary Variable

Operating System: MicroSoft Windows 10
Compiler TDM-GCC 4.9.2 64-bit
*/

//Function to Swap two Variables and return them
int* mySwapVariables(int myVarSet[])
{
	int temp;
	temp = myVarSet[0];
	myVarSet[0] = myVarSet[1];
	myVarSet[1] = temp;
	
	return &myVarSet[0];
}
int main(int argc, char *argv[])
{
	int myVarSet[2];
	
	//Read the First Variable
	printf("Enter the Value of First Variable := ");
	scanf("%d", &myVarSet[0]);
	
	//Read the Second Variable
	printf("Enter the Value of Second Variable := ");
	scanf("%d", &myVarSet[1]);
	
	//Swap the Variables using mySwapVariables function
	myVarSet[0] = *mySwapVariables(myVarSet);
	printf("Values of Variables after Swapping them:= \n");
	printf("%s%d\n", "Variable 01:= ", myVarSet[0]);
	printf("%s%d\n", "Variable 02:= ", myVarSet[1]);
	
	fflush(stdin);
	getchar();
	
	return 0;
}

