
/*
Author: Mr. Vinay Srinivasan
Org: IIRDM
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

/*
C Program to Convert Centigrade into Fahrenheit
Formula: F= (1.8 * C) + 32

Operating System: MicroSoft Windows 10
Compiler TDM-GCC 4.9.2 64-bit
*/

/*
Reusable Function to Convert given Centigrade into Fahrenheit
*/

float myCentigradeToFahrenheit(float myCentigrade)
{
	float myFahrenheit = (1.8 * myCentigrade) + 32;
	return myFahrenheit;
}

//main function
int main(int argc, char *argv[])
{
	//Clear Screen in Windows
	system("cls");
	float myCentigrade;
	printf("Enter the Centigrade to be converted into Fahrenheit:\n");
	scanf("%f", &myCentigrade);
	printf("Fahrenheit Value of %2.2f Centigrade := ", myCentigrade);
	printf("%2.2f\n", myCentigradeToFahrenheit(myCentigrade));
	fflush(stdin);
	getchar();
	return 0;
}


