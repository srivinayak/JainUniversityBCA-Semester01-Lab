/*
Author: Mr. Vinay Srinivasan
Org: IIRDM
*/

#include <stdio.h>
#include <stdlib.h>

/*
C Program to calculate the Total Salary of an employee given that:
01. Allowance1 is 33% of Basic Pay,
02. Allowance2 is 73% of Basic Pay and
03. Deduction is 52% of Basic Pay.

Operating System: MicroSoft Windows 10
Compiler TDM-GCC 4.9.2 64-bit
*/

//Structure for Employee's TotalSalary
typedef struct
{
	double BasicPay;
	double Allowance01;
	double Allowance02;
	double Deduction;
	double TotalSalary;
} employee;

//Function to Calculate Employee TotalSalary
//Address of employee Object is the input parameter
void getTotalSalary(employee* e1)
{
	e1->Allowance01 = (0.33 * e1->BasicPay);
	e1->Allowance02 = (0.73 * e1->BasicPay);
	e1->Deduction = (0.52 * e1->BasicPay);
	e1->TotalSalary = e1->BasicPay + e1->Allowance01 + e1->Allowance02 - e1->Deduction;

	return;
}

//Function to Input BasicPay and Calculate Total Salary
//of an Employee
void myEmployeeData()
{
	employee m1;
	
	printf("Enter the Basic Pay of the Employee: ");
	scanf("%lf", &m1.BasicPay);

	//Call the getTotalSalary Function with address of m1
	getTotalSalary(&m1);
	printf("The Total Salary of the Employee: ");
	printf("%10.2lf", m1.TotalSalary);
	
	return;
}


//Main Function
int main(int argc, char *argv[])
{
 	myEmployeeData();
 	
	fflush(stdin);
	getchar();
	
	return 0;
}


