/*
Author: Mr. Vinay Srinivasan
Org: IIRDM
*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/*
C Program to calculate the Simple Interest (SI):
01. Principle P
02. Terms in Number of Years N
03. Rate of Interest per Year R
Formula: SI = (P * N * R)/ 100

Operating System: MicroSoft Windows 10
Compiler TDM-GCC 4.9.2 64-bit
*/


//Function to Calculate Simple Interest
void mySimpleInterest()
{
	double Principle;
	float NTerms;
	float Rate;
	double SimpleInterest;
	
	printf("Enter the Principle:=");
	scanf("%lf", &Principle);
	
	printf("Enter the Number of Year Terms:=");
	scanf("%f", &NTerms);
	
	printf("Enter the Rate of Interest:=");
	scanf("%f", &Rate);
	
	SimpleInterest = (Principle * NTerms * Rate)/ 100;
	printf("Simple Interest Calculated is:=");
	printf("%10.2lf", SimpleInterest);
	
	return;
}


//Main Function
int main(int argc, char *argv[])
{
 	mySimpleInterest();
 	
	fflush(stdin);
	getchar();
	
	return 0;
}


