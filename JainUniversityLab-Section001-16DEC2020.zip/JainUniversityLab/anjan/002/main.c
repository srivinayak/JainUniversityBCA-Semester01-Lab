
/*
Author: Mr. Vinay Srinivasan
Org: IIRDM
*/

#include <stdio.h>
#include <stdlib.h>

/*
C program to find the:
01. area of circle and
02. circumference of a circle
Operating System: MicroSoft Windows 10
Compiler TDM-GCC 4.9.2 64-bit
*/

/*
Declaring and Setting Value of PI in a Global Variable
*/
float PI = (22.00/7.00);

/*
Reusable C Function to calculate Circumference of Circle
for a given Radius
*/
float circumference_of_circle(float radius)
{
	float circumference;
	circumference = (2 * PI * radius);
	return circumference;
}

/*
Reusable C Function to calculate Area of Circle
for a given Radius
*/
float area_of_circle(float radius)
{
	float area;
	area = (PI * (radius * radius));
	return area;
}


int main(int argc, char *argv[])
{
	/*
	Start the Program with a Clear Screen
	*/
	system("cls");
	float radius;
	printf("Enter the Radius of the Circle:\n");
	scanf("%f", &radius);
	printf("Circumference of Circle = %f\n", circumference_of_circle(radius));
	printf("Area of Circle = %f\n", area_of_circle(radius));
	fflush(stdin);
	getchar();
	return 0;
}


