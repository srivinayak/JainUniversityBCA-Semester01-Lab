
/*
Author: Mr. Vinay Srinivasan
Org: IIRDM
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <unistd.h>

/*
C program to display Your
01. Name,
02. Address and
03. City
in different lines
Operating System: MicroSoft Windows 10
Compiler TDM-GCC 4.9.2 64-bit
*/


char *getMyFullStringData(char []);

/*
Reusable C Function to read line of string
untill new line (KeyBoard Enter) is clicked
*/
char *getMyFullStringData(char *myPrompt)
{
	int i = 0;
	int MAX = 180;
	char ch[180];
	char singleChar;

	printf("%s:\n", myPrompt);
	scanf("%c", &singleChar);
	while(singleChar != '\n')
	{
		if(i == (MAX- 1))
		{
			printf("\nInput Data Length Exceeded MAX Size %d\n", MAX);
			break;
		}
		ch[i] = singleChar;
		scanf("%c", &singleChar);
	    i++;
	}
	ch[i] = '\0';
	return strdup(&ch[0]);
}

/*
Main Function
*/
int main(int argc, char *argv[])
{
	/*
	Start the Program with a Clear Screen
	*/
	system("cls");
	char myFirstName[50];
	char myLastName[50];
	char myAddress[180];
	char myCity[30];
	strcpy(myFirstName, getMyFullStringData("Enter Your First Name"));
	strcpy(myLastName, getMyFullStringData("Enter Your Last Name"));
	strcpy(myAddress, getMyFullStringData("Enter Your Address"));
	strcpy(myCity, getMyFullStringData("Enter Your City"));
	printf("Name: %s %s\n", myFirstName, myLastName);
	printf("Address: %s\n", myAddress);
	printf("City: %s\n", myCity);
	fflush(stdin);
	getchar();
	return 0;
}



